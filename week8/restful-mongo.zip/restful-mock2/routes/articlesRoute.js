const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");

const articleSchema = new mongoose.Schema({
  title: String,
  content: String,
  author: String,
  timestamp: { type: Date, default: Date.now }
}) 

const Article = new mongoose.model('Article', articleSchema);

router.get("/articles", async (request, response, next) => {
  const articles = await Article.find();
  response.send(articles);
});

router.get("/articles/:id", async (request, response, next) => {
  const id = request.params.id;
  const article = await Article.findById(id);
  response.send(article);
});

router.post("/articles", async (request, response, next) => {
  let article = new Article ({   title: request.body.title,
                                 content: request.body.content,
                                 author: request.body.author
                                 
                                });
  const result = await article.save();
  response.send(result);
});


router.put("/articles/:id", async (request, response, next) => {
  const id = request.params.id;
  const article = await Article.findById(id);
  
  article.title = "I changed the title";
  const result = await article.save();
  response.send(result);
});

router.delete("/articles/:id", async (request, response, next) => {
  const id = request.params.id;
  const result = await Article.deleteOne({ _id : id});
  response.send(result);
});

module.exports = router
